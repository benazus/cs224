After plunging USB cable, or pressing reset push-button, you have 2 seconds to press "connect to MCU"! 
Then load hex and program it.